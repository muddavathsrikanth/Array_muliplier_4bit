"""Exhaustive Boolean check of the actual X-instance netlist. No analog claims."""
from pathlib import Path
lines=Path(__file__).with_name('adder8_pdk_template.cir').read_text().splitlines()
cells={}; current=None
for line in lines:
    p=line.split()
    if not p or p[0].startswith('*'):continue
    if p[0].lower()=='.subckt':current=p[1];cells[current]=[]
    elif p[0].lower()=='.ends':current=None
    elif p[0].startswith('X') and current:cells[current].append(p)
def fa(a,b,c):
    n={'A':a,'B':b,'Cin':c}
    for g in cells['fa_1bit']:
        _,u,v,o,_,_,cell=g
        assert cell=='nand2_cmos'
        n[o]=1-(n[u]&n[v])
    return n['S'],n['Cout']
for a in range(256):
    for b in range(256):
        for ci in (0,1):
            n={'Cin':ci}
            n.update({f'A{i}':(a>>i)&1 for i in range(8)})
            n.update({f'B{i}':(b>>i)&1 for i in range(8)})
            for row in cells['adder8']:
                _,ai,bi,cin,s,co,_,_,cell=row
                assert cell=='fa_1bit'
                n[s],n[co]=fa(n[ai],n[bi],n[cin])
            got=(n['Cout']<<8)|sum(n[f'S{i}']<<i for i in range(8))
            assert got==a+b+ci,(a,b,ci,got)
print('PASS: 131072 combinations; NAND connectivity matches A+B+Cin.')
print('288 MOS devices by hierarchy count; no transistor simulation performed.')
