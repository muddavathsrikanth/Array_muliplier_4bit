45nm (GPDK045 ASSUMED) 8-BIT FULL-CUSTOM CMOS ADDER: VIRTUOSO BUILD PACKAGE

STATUS
Connectivity template and checked Boolean behavior. This is not a native
Virtuoso/OpenAccess library. Cadence/Spectre and a foundry PDK were not
available here. No transistor-level simulation, delay, power, DRC or LVS
results are claimed. The output plot is ideal logic, without propagation delay.

FILES
01: Four-MOS NAND2 circuit (body ties specified under drawing).
02: Nine NAND2 instances form a full adder. Matching wire labels connect.
03: Eight full adders form the complete 288-MOS unsigned ripple-carry adder.
04: Illustrative ideal waveform for A=FF, B=00 and toggling Cin.
adder8_pdk_template.cir: Hierarchical SPICE connectivity, no model definitions.
tb_carry_template.cir: Carry-propagation testbench, configure before running.
expected_outputs.csv: Ten reference arithmetic cases.
verify_logic.py: Evaluates the NAND connectivity from the delivered netlist.

VIRTUOSO MANUAL BUILD (straightforward and PDK-independent)
1. Create a library attached to your PDK technology.
2. Create nand2_cmos schematic with pins A B Y VDD VSS.
3. Instantiate two four-terminal PMOS and two four-terminal NMOS PDK devices.
   Follow sheet 01 and the netlist (MOS terminal order is D G S B).
   PMOS bulk to VDD; NMOS bulk to VSS. Internal series node X is local.
4. Choose permitted dimensions and supply for the PDK, Check and Save,
   then create a symbol from the cellview.
5. Create fa_1bit with A B Cin S Cout VDD VSS pins. Instantiate nine NAND
   symbols and connect according to sheet 02. Label the short wires with
   the exact net names; same-name wires within this cell are connected.
6. Make fa_1bit symbol. Create adder8, instantiate eight copies, and connect
   as sheet 03. A<0>/B<0> are LSB. All cells share supply and ground.
7. Create a separate testbench, supply source, seventeen input sources and
   output loads. Test A=FF, B=00, Cin pulsed. In ADE select the actual PDK
   model corner and Spectre; configure transient analysis and plot signals.

OPTIONAL SPICE-IN ROUTE
Use Virtuoso's Spice In importer (often File > Import > Spice in the CIW).
Input: adder8_pdk_template.cir; top subcircuit: adder8; destination: new library.
Provide the PDK reference library and device mappings for NMOS_PDK and
PMOS_PDK to the actual PDK MOS symbol masters, with correct terminal and
parameter mapping. Cell names, model names and mapping syntax depend on
your installation. Some PDK devices are subcircuit wrappers and require
adaptation of the M-device template. Import alone does not install models.
Inspect the resulting hierarchy, wire connectivity, widths, lengths, units,
and bulk connections. Check and Save every generated schematic.
Import has not been tested on a Cadence installation here.
Reference: https://support1.cadence.com/public/docs/content/11719040.html

EXAMPLE SETTINGS, ONLY IF APPROPRIATE FOR YOUR PDK
Template uses L=45nm, Wn=Wp=240nm, supply=1.0V and 10fF output loads.
These are illustrative, not optimized or universally valid.
Cin: low 0, high VDD, delay 10ns, rise/fall 100ps, width 10ns, period 20ns.
Transient stop 45ns; starting maxstep 10ps. Allow settling before checking.
The ideal chart rounds transitions to 10/20/30/40ns; finite-edge pulse source
crossings differ slightly, even before transistor delays are included.

EXPECTED OUTPUT
Cin=0: FF + 00 + 0 = 0FF -> Cout=0, S=FF.
Cin=1: FF + 00 + 1 = 100 -> Cout=1, S=00.
Plot Cin, intermediate carries, Cout and sum outputs. Real ripple carries
arrive at different times; transient intermediate sums are possible.
Measure input/output 50% crossing delays only from actual simulation.
After layout run DRC, LVS, extraction and post-layout simulation.

To make a PDK-specific runnable project, supply the PDK name/version,
NMOS/PMOS library and cell names, permitted VDD and model corner setup.

45nm UPDATE
Assumption: Cadence gpdk045, nominal-Vt core devices nmos1v/pmos1v.
Use L=45n, W=240n for each of the four NAND MOS devices, one finger,
multiplicity 1. These are starting dimensions, not optimized results.
The two series NMOS are widened relative to a 120nm reference NMOS;
each PMOS is 240nm. Supply/high input=1.0V, low input=0V.
Keep NMOS_PDK and PMOS_PDK as model placeholders until you verify your
installed model names or import device mappings. Cell and model names
are not interchangeable. In the schematic choose gpdk045/nmos1v and
gpdk045/pmos1v, symbol view, and let the PDK CDF generate the netlist.
Set the installed gpdk045.scs model file and nominal process section in ADE
(the section is often tt; verify it exists). Begin at 27 degrees Celsius.
The diagrams show connectivity and apply unchanged to this 45nm design.
No Cadence/PDK simulation has been run. Boolean output is unchanged;
analog timing and power must be measured using the real models.
Source: https://www.princeton.edu/~nverma/cadence_23.1/gpdk045_v_6_0/docs/gpdk045_pdk_referenceManual.pdf
